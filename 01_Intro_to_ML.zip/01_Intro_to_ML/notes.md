# Introduction to Machine Learning

## What is Machine Learning?
Machine Learning (ML) ek aisi technique hai jisme computers ko data dekar unhe seekhne aur future me decision lene ki capability di jati hai.

## Types of Machine Learning:
1. **Supervised Learning:** Data ke sath labels hote hain. Machine seekh kar naye data ka answer predict karti hai.
2. **Unsupervised Learning:** Data ke sath labels nahi hote. Machine data me patterns dhoondhti hai.
3. **Reinforcement Learning:** Machine environment se feedback lekar apni strategy improve karti hai.

## Applications of ML:
- Spam Detection
- Image Recognition
- Recommendation Systems
- Self Driving Cars

---
